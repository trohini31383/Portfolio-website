(function(window, undefined) {

  var jimLinks = {
    "951b8c78-918e-43a4-b5e2-137821df0ecb" : {
      "Button_1" : [
        "2fa8b899-3e93-4167-b0a1-db40590b6881"
      ],
      "Button_2" : [
        "2da89386-9a72-4838-9098-99f5b6ceda31"
      ]
    },
    "2fa8b899-3e93-4167-b0a1-db40590b6881" : {
      "Image_17" : [
        "951b8c78-918e-43a4-b5e2-137821df0ecb"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);